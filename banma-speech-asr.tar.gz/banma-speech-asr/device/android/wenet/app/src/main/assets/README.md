put final.zip and words.txt here.
