/**
* @file Diamond.h
* @说明:
* @客户端功能接口
* 
*
* @author: qingzhi
*
* @create date：2014-10-22
*
*/
#ifndef __DIAMOND_H__
#define __DIAMOND_H__

#include <unistd.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <list>
#include "BatchHttpResult.h"
#include "ConfigInfoEx.h"
#include "ConfigKey.h"

//getconfig的feature参数
const int GETCONFIG_LOCAL_SERVER_SNAPSHOT = 1;//获取数据的顺序：容灾文件-> 服务器 -> 本地缓存
const int GETCONFIG_LOCAL_SNAPSHOT_SERVER = 2;//获取数据的顺序：容灾文件-> 本地缓存 -> 服务器
//ConfigInfoEx  getStatus()返回值对应含义
// 发生异常
const  int BATCH_OP_ERROR = -1;
const  std::string BATCH_OP_ERROR_IO_MSG = "get config dump error";
const  std::string BATCH_OP_ERROR_CONFLICT_MSG = "config get conflicts";
// 查询成功, 数据存在
const  int BATCH_QUERY_EXISTS = 1;
const  std::string BATCH_QUERY_EXISTS_MSG = "config exits";
// 查询成功, 数据不存在
const  int BATCH_QUERY_NONEXISTS = 2;
const  std::string BATCH_QUERY_NONEEXISTS_MSG = "config not exits";
// 新增成功
const  int BATCH_ADD_SUCCESS = 3;
// 更新成功
const  int BATCH_UPDATE_SUCCESS = 4;

const  int MAX_UPDATE_FAIL_COUNT = 5;
const  int MAX_UPDATEALL_FAIL_COUNT = 5;
const  int MAX_REMOVE_FAIL_COUNT = 5;
const  int MAX_REMOVEALL_FAIL_COUNT = 5;
const  int MAX_NOTIFY_COUNT = 5;
const  int MAX_ADDACK_COUNT = 5;

namespace middleware{
namespace diamond{

class DiamondEnv;
//该类具体由业务实现监听器
class ManagerListener 
{
public:
    ManagerListener(){}
    virtual ~ManagerListener(){}
    virtual void getExecutor()=0;

    /** 
    * @brief 回调获取配置信息 
    * 
    * @param[in] configInfo 获取到的内容
    */
    virtual void receiveConfigInfo( std::string &configInfo) = 0;
};

class Diamond
{
public:
    //设置是否多进程共享数据，默认不共享
    static void SetShareMode(bool bShare);
    //设置应用名字
    static void SetAppName(const char* app_name);
    //设置缓存路径
    static void SetCachePath(const char* path);
    //设置日志路径
    static void SetLogPath(const char* path);
    //设置/dev/shm/的777权限
    static bool SetDevShmMode777();

    //设置顶级域名，默认为jmenv.tbsite.net
    static bool SetGlobalJMENV(const char* jmenv = "jmenv.tbsite.net", int port = 8080);
    //设置域名，命名空间，ak/sk
    static void init(const char* jmenv, const char* nameSpace, char* accessKey, char* secretKey, int port = 8080);
    /** 
    * @brief 设置客户端工作模式，决定是否拉线程 
    * 
    * 功能:该接口用于设置客户端工作模式
    * @param[in] bThreadMode true  线程模式，支持监听器，默认值
                             false 非线程模式，不支持监听器
    */
    static  void SetWorkMode(bool bThreadMode);


    /** 
    * @brief shutdown 
    * 
    * 使用线程模式时，程序退出时必须调用
    */
    static void shutdown();

    //注册配置变更后回调的监听器，实现异步监听服务端配置变更

    /** 
    * @brief 添加监听器 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] listener 监听器
    * @param[in] pfixedEnv Defaults to NULL.
    */
    static  void addListener(const std::string &dataId,\
                             const std::string &group,\
                             ManagerListener* listener,\
                             DiamondEnv *pfixedEnv = NULL);

    /** 
    * @brief 批量添加监听器 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] listeners 监听器列表
    * @param[in] pfixedEnv Defaults to NULL.
    */
    static  void addListeners(const std::string &dataId,\
                              const  std::string &group,\
                              std::list<ManagerListener*>& listeners,\
                              DiamondEnv *pfixedEnv = NULL); 

    /** 
    * @brief 同步阻塞获取配置 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] timeoutMs 超时时间毫秒
    * @param[out] content 获取到的内容
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool true  成功
                   false 失败
    */
    static bool getConfig(const std::string &dataId,\
                          const std::string &group,\
                          int timeoutMs,\
                          std::string &content,\
                          DiamondEnv *pfixedEnv = NULL); 

    /** 
    * @brief 删除监听器 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] listener 监听器
    * @param[in] pfixedEnv Defaults to NULL.
    */
    static  void removeListener(const std::string &dataId,\
                                const std::string &group,\
                                ManagerListener* listener,\
                                DiamondEnv *pfixedEnv = NULL);

    /** 
    * @brief 获取监听器列表
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] pfixedEnv Defaults to NULL.
    * @return std::list<ManagerListener*> 存放监听器列表的指针
    */
    static std::list<ManagerListener*> getListeners(const std::string &dataId,\
                                                    const std::string &group,\
                                                    DiamondEnv *pfixedEnv = NULL);

    /** 
    * @brief 同步阻塞获取配置 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] feature 获取顺序
                 const int GETCONFIG_LOCAL_SERVER_SNAPSHOT = 1;//获取数据的顺序：容灾文件-> 服务器 -> 本地缓存
                 const int GETCONFIG_LOCAL_SNAPSHOT_SERVER = 2;//获取数据的顺序：容灾文件-> 本地缓存 -> 服务器
    * @param[in] timeoutMs 超时时间毫秒
    * @param[out] content 获取到的内容
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool true  成功
                   false 失败
    */
    static bool getConfig(const std::string &dataId,\
                          const std::string &group,\
                          int feature,\
                          int timeoutMs,\
                          std::string &content,\
                          DiamondEnv *pfixedEnv = NULL);

    /** 
    * @brief 推送非聚合数据（数据的添加和更新） 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] content 配置内容
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool true  成功
                   false 失败 
    */
    static  bool publishSingle(const std::string &dataId,\
                               const std::string &group,\
                               const std::string &content,\
                               DiamondEnv *pfixedEnv = NULL) ;

    /** 
    * @brief 推送聚合数据（数据的添加和更新） 
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] datumId 子配置键
    * @param[in] content 配置内容
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool true  成功
                   false 失败 
    */
    static  bool publishAggr(const std::string &dataId,\
                             const std::string &group,\
                             const std::string &datumId,\
                             const std::string &content,\
                             DiamondEnv *pfixedEnv = NULL);
    /** 
    * @brief 删除非聚合数据
    * 
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool  true  成功
                    false 失败
    */
    static  bool remove(const std::string &dataId,\
                        const std::string &group,\
                        DiamondEnv *pfixedEnv = NULL); 

    /** 
    * @brief 删除聚合数据 
    * 
    * @param[in] dataId 配置键
    * @param[in] groupconst 配置组
    * @param[in] datumId 子配置键
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool  true  成功
                    false 失败
    */
    static  bool removeAggr(const std::string &dataId,\
                            const std::string &groupconst,\
                            const std::string &datumId,\
                            DiamondEnv *pfixedEnv = NULL); 

    /** 
    * @brief 批量查询配置的值 
    * 
    * @param[in]  dataIds 配置键列表
    * @param[in]  group 配置组
    * @param[in]  timeoutMs 超时时间毫秒
    * @param[out] HttpResult 获取到的结果
    * @param[in]  pfixedEnv Defaults to NULL.
    * @return     bool true  成功
                       false 失败 
    */
    static bool batchQuery(std::list<std::string>& dataIds,\
                           std::string &group,int timeoutMs,\
                           BatchHttpResult<ConfigInfoEx>& HttpResult,\
                           DiamondEnv *pfixedEnv = NULL);

    /** 
    * @brief 批量查询配置的server snapshot值 
    * 
    * @param[in] dataIds 配置键列表
    * @param[in] group 配置组
    * @param[in] timeoutMs 超时时间毫秒
    * @param[out] HttpResult 获取到的结果
    * @param[in] pfixedEnv Defaults to NULL.
    * @return bool  true  成功
                    false 失败 
    */
    static  bool batchGetConfig(std::list<std::string>& dataIds,\
                                std::string &group,\
                                int timeoutMs,\
                                BatchHttpResult<ConfigInfoEx>& HttpResult,\
                                DiamondEnv *pfixedEnv = NULL);
    /**
	 * 查询租户下的所有的配置
	 * @param[in]  timeoutMs
	 * @param[out] configs
	 * @return bool true  成功
					false 失败
	 */
    static  bool getConfigs(std::list<ConfigKey>& configs, int timeoutMs, DiamondEnv *pfixedEnv = NULL);

    /*注意目前版本批量查询接口及单元化暂不实现*/
    /*获取目标环境接口*/

    static  DiamondEnv* getTargetEnv(std::list<std::string> &serverIps);

    // 获取指定单元下的的环境
    static  DiamondEnv* getDiamondUnitEnv(const std::string& unitName);

    /*获取批量目标环境接口*/
    static  bool allDiamondEnvs(std::list<DiamondEnv*>& vDiamondEnv);
};

}
}
#endif
