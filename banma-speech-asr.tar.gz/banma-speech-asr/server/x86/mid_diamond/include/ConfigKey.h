/**
* @file ConfigKey.h
* @brief
*
* @tips:
*
* @author: tsing
*
* @ctreate date��2018-02-05
*
*/
#ifndef __CONFIGKEY_H__
#define __CONFIGKEY_H__

#include <stdlib.h>
#include <vector>
#include <string>
#include <list>

namespace middleware{
namespace diamond{

class ConfigKey
{
public:
	ConfigKey();

    std::string getDataId();
    void setDataId(std::string sDataId);
    std::string getGroup();
    void setGroup(std::string sGroup);
    std::string getAppName();
    void setAppName(std::string sAppName);

private:
    std::string m_sDataId;
    std::string m_sGroup;
    std::string m_sAppName;
};

}
}

#endif
