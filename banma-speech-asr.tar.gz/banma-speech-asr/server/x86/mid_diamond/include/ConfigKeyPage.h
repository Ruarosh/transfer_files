/**
* @file ConfigKeyPage.h
* @brief
*
* @tips:
*
* @author: tsing
*
* @ctreate date��2018-02-05
*
*/
#ifndef __CONFIGKEY_PAGE_H__
#define __CONFIGKEY_PAGE_H__

#include <stdlib.h>
#include <vector>
#include <string>
#include <list>
#include "ConfigKey.h"

namespace middleware{
namespace diamond{

class ConfigKeyPage
{
public:
	ConfigKeyPage();

    int getTotalCount();
    void setTotalCount(int dwTotalCount);
    int getPageNumber();
    void setPageNumber(int dwPageNumber);
	int getPagesAvailable();
    void setPagesAvailable(int dwPagesAvailable);
    std::list<ConfigKey> getPageItems();
    void setPageItems(std::list<ConfigKey> dwPageItems);
    

private:
    int m_sTotalCount;
    int m_sPageNumber;
    int m_sPagesAvailable;
public:
    std::list<ConfigKey> m_sPageItems;
};

}
}

#endif
