/**
 * @file ConfigInfoEx.h
 * @brief
 *
 * @tips:
 *
 * @author: qingzhi
 *
 * @ctreate date��2014-11-25
 *
 */
#ifndef __CONFIGINFOEX_H__
#define __CONFIGINFOEX_H__

#include <stdlib.h>
#include <vector>
#include <string>
#include <list>

namespace middleware {
namespace diamond {

class ConfigInfoEx {
public:
	ConfigInfoEx();

	long getid();
	void setid(long dwId);

	std::string getDataId();
	void setDataId(std::string sDataId);

	std::string getGroup();
	void setGroup(std::string sGroup);

	std::string getTenant();
	void setTenant(std::string tenant);

	std::string getContent();
	void setContent(std::string sContent);

	std::string getMd5();
	void setMd5(std::string sMd5);

	int getStatus();
	void setStatus(int status);
	std::string getMessage();

	void setMessage(std::string message);

	std::string toString();
	std::string IntToString(int n);
private:
	//long serialVersionUID;
	long m_dwLastModifiedTs;

	long m_dwId;
	std::string m_sDataId;
	std::string m_sGroup;
	std::string m_sTenant;
	std::string m_sContent;
	std::string m_sMd5;
	// 批量查询时, 单条数据的状态码, 具体的状态码在Constants.java中
	int m_iStatus;
	// 批量查询时, 单条数据的信息
	std::string m_sMessage;
};

}
}

#endif
