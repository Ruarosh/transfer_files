/**
* @file BatchHttpResult.h
* @brief ģ����
*
* @tips:
*
* @author: qingzhi
*
* @ctreate date��2014-11-25
*
*/
#ifndef __BATCHHTTP_H__
#define __BATCHHTTP_H__
#include <stdlib.h>
#include <vector>
#include <string>
#include <list>
#include<stdio.h> 

namespace middleware{
namespace diamond{

template <class T>
class BatchHttpResult
{
public:
    BatchHttpResult()
    {
    }
    BatchHttpResult(bool bsuccess, int istatusCode, std::string& statusMsg, std::string& responseMsg)
    {
        m_bSuccess = bsuccess;
        m_iStatusCode = istatusCode;
        m_statusMsg = statusMsg;
        m_responseMsg = responseMsg;
    }
    bool isSuccess()
    {
        return m_bSuccess;
    }
    void setSuccess(bool bSuccess)
    {
        m_bSuccess = bSuccess;
    }
    int getStatusCode()
    {
        return m_iStatusCode;
    }
    void setStatusCode(int istatusCode)
    {
        m_iStatusCode = istatusCode;
    }
    void getStatusMsg(std::string &sStatusMsg)
    {
        sStatusMsg =  m_statusMsg;
    }
    void setStatusMsg(const std::string &statusMsg)
    {
        m_statusMsg = statusMsg;
    }
    void getResponseMsg(std::string &sResponseMsg)
    {
        sResponseMsg =  m_responseMsg;
    }
    void setResponseMsg(const std::string &responseMsg)
    {
        m_responseMsg = responseMsg;
    }
    void getResult(std::list<T> & vResult)
    {
        vResult =  m_vResult;
    }
    void setResult(std::list<T> & vResult)
    {
        m_vResult =  vResult;
    }
    std::string toString()//+ m_bSuccess + UtilAll::Int32ToString(m_iStatusCode)
    {
        std::string printStr ;
        printStr.append("BatchHttpResult [bSuccess=").append(boolToString(m_bSuccess)).append(", StatusCode=")
            .append(IntToString(m_iStatusCode)).append(", statusMsg=")
            .append(m_statusMsg).append(", m_responseMsg=").append(m_responseMsg).append("]");
        return printStr;
    }
    std::string IntToString(int n)
    {
        char buf[128] = "";
        snprintf(buf, sizeof(buf), "%d", n);
        return buf;
    }
    std::string boolToString(bool  bpara)
    {
        char szStr[8] = {0};
        snprintf(szStr, sizeof(szStr) - 1, "%d", bpara);
        return szStr;
    }

private:
    // �������Ƿ�ɹ�
    bool m_bSuccess;
    // ���󷵻ص�״̬��
    int m_iStatusCode;
    // �û��ɶ��ķ�����Ϣ
    std::string m_statusMsg;
    // response�е�Ԫ��Ϣ
    std::string m_responseMsg;
    // ���صĽ����
public:
    std::list<T> m_vResult;

};

}
}

#endif
