/**
* @file ACM.h
* @说明:
* @客户端功能接口
*
*
* @author: qingzhi
*
* @create date：2017-10-22
*
*/
#ifndef __ACM_H__
#define __ACM_H__

#include <string>
#include "Diamond.h"

namespace acm{
using namespace middleware::diamond;

class ACM
{
public:
    //设置域名，命名空间，ak/sk
    static void init(const char* domain, const char* nameSpace, char* accessKey, char* secretKey);

    /**
    * @brief 添加监听器
    *
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] listener 监听器
    */
    static  void addListener(const std::string &dataId,\
                             const std::string &group,\
                             ManagerListener* listener);

    /**
    * @brief 同步阻塞获取配置
    *
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] timeoutMs 超时时间毫秒
    * @param[out] content 获取到的内容
    * @return bool true  成功
                   false 失败
    */
    static bool getConfig(const std::string &dataId,\
                          const std::string &group,\
                          int timeoutMs,\
                          std::string &content);

    /**
	 * 查询租户下的所有的配置
	 * @param[in]  timeoutMs
	 * @param[out] configs
	 * @return bool true  成功
					false 失败
	 */
	static  bool getConfigs(std::list<ConfigKey>& configs, int timeoutMs);

    /**
    * @brief 删除监听器
    *
    * @param[in] dataId 配置键
    * @param[in] group  配置组
    * @param[in] listener 监听器
    */
    static  void removeListener(const std::string &dataId,\
                                const std::string &group,\
                                ManagerListener* listener);
};
}
#endif
